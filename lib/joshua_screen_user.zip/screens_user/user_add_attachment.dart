import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

import '../models/user_transaction.dart';

class UserAddAttachment extends StatefulWidget {
  final Transaction transaction;
  final List<String> selectedDetails;

  UserAddAttachment({required this.transaction, required this.selectedDetails});
  @override
  _UserAddAttachmentState createState() => _UserAddAttachmentState();
}

class _UserAddAttachmentState extends State<UserAddAttachment> {
  List<UploadFile> uploadFiles = [];
  bool isUploading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Upload and Attach Files'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () async {
                await pickFile();
              },
              child: Text('Click to Upload'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color.fromARGB(255, 79, 128, 189),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: uploadFiles.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    onTap: () {
                      // Show image or file details dialog
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: Text('File Details'),
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('File Name: ${uploadFiles[index].name}'),
                              SizedBox(height: 8),
                              Text('File Size: ${(uploadFiles[index].size / 1024).toStringAsFixed(2)} KB'),
                              if (uploadFiles[index].filePath != null && _isImageFile(uploadFiles[index].name))
                                Image.file(
                                  File(uploadFiles[index].filePath!),
                                  width: 200,
                                  height: 200,
                                  fit: BoxFit.cover,
                                ),
                            ],
                          ),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text('Close'),
                            ),
                          ],
                        ),
                      );
                    },
                    leading: Icon(Icons.attach_file, color: Colors.blue),
                    title: Text(uploadFiles[index].name),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        LinearProgressIndicator(
                          value: uploadFiles[index].progress,
                          backgroundColor: Colors.grey[200],
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                        ),
                        SizedBox(height: 5),
                        Text(uploadFiles[index].progress >= 1.0
                            ? '100% Uploaded'
                            : '${(uploadFiles[index].progress * 100).toStringAsFixed(0)}%'),
                      ],
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () {
                        setState(() {
                          uploadFiles.removeAt(index);
                        });
                      },
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      uploadFiles.clear();
                    });
                  },
                  child: Text('Discard'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    _attachFiles();
                  },
                  child: Text('Attach Files'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 79, 128, 189),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile file = result.files.first;

      if (file.bytes != null) {
        // Handling file upload on web using file.bytes
        // Example: Convert bytes to base64 or upload directly to server
        print('File picked: ${file.name}, size: ${file.size}');
        // For demonstration, here we assume file is uploaded directly
        // You may handle it as per your actual upload logic
        final uploadFile = UploadFile(
          name: file.name,
          size: file.size,
          filePath: null, // On web, we typically don't store path
        );
        setState(() {
          uploadFiles.add(uploadFile);
        });
      } else {
        // Handling file upload on mobile using file.path
        final uploadFile = UploadFile(
          name: file.name,
          size: file.size,
          filePath: file.path,
        );

        setState(() {
          uploadFiles.add(uploadFile);
          isUploading = true;
        });

        Timer.periodic(Duration(milliseconds: 1000), (timer) {
          setState(() {
            uploadFile.progress += 0.1;
            if (uploadFile.progress >= 1.0) {
              uploadFile.progress = 1.0;
              timer.cancel();
              isUploading = false;
            }
          });
        });
      }
    }
  }

  bool _isImageFile(String fileName) {
    final ext = fileName.split('.').last.toLowerCase();
    return ext == 'jpg' || ext == 'jpeg' || ext == 'png' || ext == 'gif' || ext == 'bmp';
  }

  void _attachFiles() {
    // Simulate attaching files or implement actual logic here
    print('Files attached: ${uploadFiles.map((file) => file.name).toList()}');
    // Clear uploaded files after attaching
    setState(() {
      uploadFiles.clear();
    });
  }
}

class UploadFile {
  final String name;
  final int size;
  double progress;
  final String? filePath;

  UploadFile({
    required this.name,
    required this.size,
    this.progress = 0.0,
    this.filePath,
  });
}
